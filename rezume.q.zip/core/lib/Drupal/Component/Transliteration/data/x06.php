<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', NULL, NULL, NULL,
  0x10 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ';', NULL, NULL, NULL, '?',
  0x20 => NULL, '', 'a', 'a', 'w', 'a', 'y', 'a', 'b', 't', 't', 'th', 'j', 'h', 'kh', 'd',
  0x30 => 'dh', 'r', 'z', 's', 'sh', 's', 'd', 't', 'z', '`', 'gh', NULL, NULL, NULL, NULL, NULL,
  0x40 => '', 'f', 'q', 'k', 'l', 'm', 'n', 'h', 'w', 'y', 'y', 'an', 'un', 'in', 'a', 'u',
  0x50 => 'i', 'W', '', '', '\'', '\'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x60 => '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '%', ',', '.', '*', NULL, NULL,
  0x70 => '', '\'', '\'', '\'', '', '\'', '\'w', '\'u', '\'y', 'tt', 'tth', 'b', 't', 'T', 'p', 'th',
  0x80 => 'bh', '\'h', 'H', 'ny', 'dy', 'H', 'ch', 'cch', 'dd', 'D', 'D', 'Dt', 'dh', 'ddh', 'd', 'D',
  0x90 => 'D', 'rr', 'R', 'R', 'R', 'R', 'R', 'R', 'zh', 'R', 'S', 'S', 'S', 'S', 'S', 'T',
  0xA0 => 'GH', 'F', 'F', 'F', 'v', 'f', 'ph', 'Q', 'Q', 'k', 'k', 'K', 'K', 'ng', 'K', 'g',
  0xB0 => 'G', 'N', 'G', 'G', 'G', 'L', 'L', 'L', 'L', 'N', 'N', 'N', 'N', 'N', 'h', 'Ch',
  0xC0 => 'hy', 'h', 'H', '@', 'W', 'oe', 'oe', 'u', 'yu', 'yu', 'W', 'v', 'y', 'Y', 'Y', 'W',
  0xD0 => '', '', 'y', 'y\'', '.', 'ae', '', '', '', '', '', '', '', '@', '#', '',
  0xE0 => '', '', '', '', '', '', '', '', '', '^', '', '', '', '', NULL, NULL,
  0xF0 => '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'Sh', 'D', 'Gh', '&', '+m', NULL,
];
